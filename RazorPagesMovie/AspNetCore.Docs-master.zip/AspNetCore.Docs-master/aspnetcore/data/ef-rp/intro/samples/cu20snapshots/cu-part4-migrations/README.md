Copy wwwroot from ../cu/ or from a new Razor Pages project.

Run `dotnet ef database update`
